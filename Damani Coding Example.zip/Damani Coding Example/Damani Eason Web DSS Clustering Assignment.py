#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn import svm
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split


# In[3]:


# Read in Project File
data = pd.read_csv('movies_metadata.csv')
# Drop Unknown Values
data = data.dropna()
data.info()


# In[4]:


# Drop the movies with less than 250 votes and a score less than 6
data=data[data['vote_count']>250.0]
data=data[data['vote_average']>6]
data.info()


# In[7]:


# Apply label Encoding to Genres 1 and 2
from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()

data[['genre1']] = data[['genre1']].apply(le.fit_transform)
data[['genre2']] = data[['genre2']].apply(le.fit_transform)

data


# In[9]:


#Scaling the data so that the features of interest become comparable.

from sklearn.preprocessing import StandardScaler, normalize 
from sklearn.decomposition import PCA

# Standard Scaler
scaler = StandardScaler()
X = data[['genre1', 'genre2','runtime', 'vote_average', 'vote_count']]
X_scaled = scaler.fit_transform(X)


# Applying Principle Component Analysis (PCA)
pca = PCA(n_components=2)
X_prin = pca.fit_transform(X_scaled)
X_prin = pd.DataFrame(X_prin) 
#data1
X_prin.columns=['P1','P2']
X = X_prin
X.head()


# In[10]:


# Visualize the PCA 
fig, ax = plt.subplots()
x1 = X_prin['P1']
x2 = X_prin['P2']
scatter = ax.scatter(x1,x2)


# In[14]:


# Apply Clustering 

from sklearn.cluster import KMeans, MeanShift, DBSCAN, AgglomerativeClustering

#Kmeans 

data['km pred'] = KMeans().fit_predict(X)

#Meanshift
data['ms pred'] = MeanShift().fit_predict(X)

#DBSCAN
data['db pred'] = DBSCAN().fit_predict(X)

#AgglomerativeClustering 
data['ac pred'] = AgglomerativeClustering().fit_predict(X)

data.head()


# In[15]:


# Visualize the Clusters
for i in range(-4,0): 
    fig, ax = plt.subplots()
    scatter = ax.scatter(X['P1'], X['P2'], c= data.iloc[:,i], cmap='rainbow')
    legend = fig.legend(*scatter.legend_elements(), loc='upper right', title = 'Classes')
    


# In[17]:


# Analyse the Clusters using silhoutte and david bouldin 
from sklearn.metrics import silhouette_score, davies_bouldin_score
best_sil = []
best_dav = []
print(silhouette_score(X_prin, data['km pred']), davies_bouldin_score(X_prin, data['km pred']))
best_sil.append(silhouette_score(X_prin, data['km pred']))
best_dav.append(davies_bouldin_score(X_prin, data['km pred']))

print(silhouette_score(X_prin, data['ms pred']), davies_bouldin_score(X_prin, data['ms pred']))
best_sil.append(silhouette_score(X_prin, data['ms pred']))
best_dav.append(davies_bouldin_score(X_prin, data['ms pred']))

print(silhouette_score(X_prin, data['db pred']), davies_bouldin_score(X_prin, data['db pred']))
best_sil.append(silhouette_score(X_prin, data['db pred']))
best_dav.append(davies_bouldin_score(X_prin, data['db pred']))

print(silhouette_score(X_prin, data['ac pred']), davies_bouldin_score(X_prin, data['ac pred']))
best_sil.append(silhouette_score(X_prin, data['ac pred']))
best_dav.append(davies_bouldin_score(X_prin, data['ac pred']))

print('\nThe best Silhouette score is', max(best_sil), "generated using Mean Shift method.")
print('\nThe best Davis score is', min(best_dav), "generated using Mean Shift method.")


# In[20]:


for i in range(2,20):
    data['km pred']=KMeans(n_clusters=i).fit_predict(X)
    print(silhouette_score(X, data['km pred']), davies_bouldin_score(X, data['km pred']))
print("The best number of clusters based on the silhoutte score is 2.")
    

